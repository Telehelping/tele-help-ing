# Tele-Help-Ing website revamp — GHL-ready draft

## What is inside
- `index.html`: cleaner group/brand homepage; no general lead-capture form.
- `style.css` and `script.js`: responsive, accessible static design.
- `privacy-policy/index.html`: privacy disclosure for the website and SMS program.
- `terms-and-conditions/index.html`: website and SMS terms.
- `sms-consent/index.html`: dedicated page for genuine, optional SMS enrollment.
- `netlify.toml`: basic redirects and protective headers.
- HighLevel widget from screenshot is embedded on both the homepage and the SMS consent page. No other SMS form is present in these new files.

## CRITICAL ITEMS TO VERIFY BEFORE PUBLISHING/SUBMITTING A2P
1. **Legal entity conflict:** your GHL screenshot says `TELE-HELP LLC`, whereas the 2026 group MSA and public Clutch verification identify `Tele-Help-Ing, Inc.`. Confirm which **legal name/EIN** is currently registered for SMS and correct the site or GHL brand so they agree. Do not make a misleading DBA claim without documentation. Changing registration may have additional steps.
2. **Business address:** draft uses `7121 W. Craig Rd, Ste 113 PMB 1040, Las Vegas, NV 89121` from a July 2025 Tele-Help-Ing privacy document. Public Clutch listing has a different ZIP (89129). Verify the current legal/contact address and match the address entered in GHL before launch; replace it in all HTML files if different.
3. **Business phone number:** a verified public business phone was not found. Add your actual current business contact phone consistently in the footer, policy, terms, and consent page if GHL checklist requests it, and ensure it agrees with GHL. Do NOT make one up.
4. **Email:** `info@telehelping.com` was found in an existing Tele-Help-Ing privacy policy and public references. Confirm the mailbox is monitored.
5. **Legal text review:** Privacy and Terms pages are implementation drafts, not a legal opinion. Verify they reflect your actual vendors, retention, SMS uses, cross-border processing, data-sharing terms, cookie practices, and regulatory obligations before you publish them.
6. **Sending behavior:** only send SMS to recipients who actually opted in, within the message category consented to. A working widget for carrier review does not consent your preexisting contacts. If you collect consent verbally or in contracts, document it accurately and consider HighLevel Manual Setup for that method.
7. **The Coaches VA:** it appears in the older public repository, but its external website could not be independently verified. Omitted from the new homepage until its URL is confirmed live.
8. **Existing pages:** the repository has legacy subpages (`schedule`, `marketing`, `legal`, and others). This package intentionally replaces the homepage and adds legal/SMS pages. Keep old paths/files in the repository until you review any existing links or HubSpot forms, then redirect or retire them deliberately.

## Fastest deployment via existing GitHub -> Netlify link
1. In Netlify, open **the project with the production domain telehelping.com / www.telehelping.com**, then check **Domain management** and **Build & deploy > Continuous deployment** to identify the exact repository/branch. Two similarly named Netlify projects exist in your screenshot; don't assume which one serves the domain.
2. Back up the repository and current published site first.
3. In the correct GitHub repository/branch, upload these files **preserving folder structure**, replacing only `index.html`, `style.css`, `script.js`, and `netlify.toml`; adding the three directories. GitHub `Add file > Upload files` supports replacing files but be careful to preserve directory paths. Leave existing `assets` and legacy directories untouched.
4. Commit. If linked, Netlify should deploy the commit automatically. Check Netlify Deploys. If not linked, confirm the correct project before any manual deployment.
5. Verify live `https://www.telehelping.com/`, `https://www.telehelping.com/privacy-policy/`, `https://www.telehelping.com/terms-and-conditions/`, and `https://www.telehelping.com/sms-consent/`. Verify both apex and www route to the same pages, and that every brand/footnote link works.
6. Test the HighLevel chat widget in a private browsing window on both the homepage and the consent page. Confirm it uses the correct GHL location/campaign, includes optional unchecked disclosures, captures separate marketing/informational consent for Mixed, and that GHL logs the actual consent.
7. In HighLevel Chat Widget Setup, use website URL `https://www.telehelping.com/` (because the widget is installed there). Include the actual Privacy Policy and Terms URLs above. If you prefer only the consent page as the reference, you can ask GHL to review `https://www.telehelping.com/sms-consent/`, but confirm its automated scan accepts that path.
8. Run `Review Application`, fix any findings, then submit. HighLevel approval review is not the same as final carrier approval.

## GHL widget embed from screenshot
```html
<script src="https://widgets.leadconnectorhq.com/loader.js"
  data-resources-url="https://widgets.leadconnectorhq.com/chat-widget/loader.js"
  data-widget-id="6aee570a5fefb8449980fd55"></script>
```

## Ownership transfer — separate future task
- Create company-controlled GitHub and Netlify admin accounts, with multiple company admins and recovery access.
- Transfer the GitHub repo and Netlify site with the former employee's participation/authorized access.
- Verify DNS, domains, environment variables, API tokens, deploy keys, and billing before deactivating old accounts.
- Check `www` and apex routing as well as the two similarly named Netlify sites.
- Do not rush this while the A2P approval workflow is blocked unless there is an immediate account-security issue.
