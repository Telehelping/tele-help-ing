(()=>{
  const toggle=document.querySelector('[data-menu-toggle]');
  const nav=document.getElementById('primary-nav');
  if(toggle&&nav){
    toggle.addEventListener('click',()=>{
      const open=toggle.getAttribute('aria-expanded')!=='true';
      toggle.setAttribute('aria-expanded',String(open));
      nav.classList.toggle('is-open',open);
    });
    nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{
      toggle.setAttribute('aria-expanded','false');nav.classList.remove('is-open');
    }));
  }
  document.querySelectorAll('[data-year]').forEach(x=>x.textContent=new Date().getFullYear());
})();
